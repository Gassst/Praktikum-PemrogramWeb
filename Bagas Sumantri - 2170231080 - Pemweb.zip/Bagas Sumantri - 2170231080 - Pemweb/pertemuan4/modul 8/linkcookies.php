<?php 
setcookie("variable_cookies", "ini adalah variable cookies",time()+60);
echo "<a href=cekcookies.php>Cek Cookies</a>"
?>