<!DOCTYPE html>
<html>
<head>
	<title>Tanggalan</title>
</head>
<body>
<?php 
echo date("m-F-Y, g:i:s a");
?>
</body>
</html>