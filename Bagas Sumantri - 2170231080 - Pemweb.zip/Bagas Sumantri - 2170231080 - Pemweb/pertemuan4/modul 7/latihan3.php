<!DOCTYPE html>
<html>
<head>
	<title>Konversi Tipe</title>
</head>
<body>
<?php 
$a = 300.4;
echo $a;
echo "<br>";
echo "Tipe Double : ", doubleval($a), "<br>";
echo "Tipe Integer : ", intval($a), "<br>";
echo "Tipe String : ", strval($a);
?>
</body>
</html>