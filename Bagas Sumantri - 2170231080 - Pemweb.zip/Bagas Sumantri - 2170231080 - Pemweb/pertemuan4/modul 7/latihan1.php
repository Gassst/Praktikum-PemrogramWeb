<!DOCTYPE html>
<html>
<head>
	<title>Variabel</title>
</head>
<body>
<?php
$nilai_1 = 10;
$nilai_2 = 3;
$nilai_3 = 2 * $nilai_1 + 8 * $nilai_2;
echo "nilai = ", $nilai_3;
echo "<br>";
$jumlah = $nilai_1 + $nilai_2;
echo "Hasil dari $nilai_1 + $nilai_2 adalah $jumlah"; echo "<br><br>";
echo "\" Nama : Bagas Sumantri\" <br>";
echo "NIM : 2170231080"; 
?>
</body>
</html>